To turn in homework 4, create files (and subdirectories if needed) in
this directory, add and commit those files to your cloned repository,
and push your commit to your bare repository on GitHub.

Add any general notes or instructions for the TAs to this README file.
The TAs will read this file before evaluating your work.

upload image:
https://docs.djangoproject.com/en/1.10/topics/http/file-uploads/


sending mails:
https://docs.djangoproject.com/en/1.10/topics/email/

PasswordChangeForm documentation for changing user password:
https://docs.djangoproject.com/en/1.10/topics/auth/default/

password reset by email documentation:
https://docs.djangoproject.com/en/1.7/_modules/django/contrib/auth/views/
https://docs.djangoproject.com/en/1.10/topics/auth/default/
https://www.youtube.com/watch?v=I8osOkJMPBE

css, style:
http://getbootstrap.com/